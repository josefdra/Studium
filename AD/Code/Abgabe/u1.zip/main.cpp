#include "u1.hpp"

int main()
{
    one();
    two();
    three();
}