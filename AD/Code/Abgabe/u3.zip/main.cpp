#include "u3.hpp"

int main()
{
    std::vector<std::vector<int>> v = {{5, 7, -3, 8, -27, 30},
                                       {-5, 4, 8, -8, 9, 10},
                                       {9, 1, 2, 3, 4, 5},
                                       {20, -10, -9, 70, -68, 50},
                                       {11, -5, -3, 19, -20, 7}};
    max_part_sum_2d(v);
}