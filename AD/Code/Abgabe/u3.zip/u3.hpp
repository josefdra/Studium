#ifndef U3_H
#define U3_H

#include <Bits.h>
#include <vector>
#include <iostream>

void max_part_sum_2d(std::vector<std::vector<int>> &matrix);

#endif // U3_H